import React, { useState } from 'react';

function App() {
  const [currentScreen, setCurrentScreen] = useState('initial');

  // Стили для контейнера с кнопками
  const textContainerStyle = {
    display: 'flex',
    flexDirection: 'column', // Размещаем элементы вертикально
    justifyContent: 'center',
    alignItems: 'center',
    gap: '20px',
    padding: '20px',
  };

  // Общие стили для текста
  const baseTextStyle = {
    color: 'white',
    fontSize: '72px',
    fontWeight: 'bold',
    textShadow: '2px 2px 4px rgba(0, 0, 0, 0.5)',
    cursor: 'pointer',
    transition: 'transform 0.3s ease',
  };

  return (
    <div style={{ 
      width: '100vw', 
      height: '100vh', 
      backgroundColor: currentScreen === 'initial' ? '#1E90FF' : 
                       currentScreen === 'second' ? '#FFD700' : 
                       currentScreen === 'third' ? '#000000' : '#FFA500', // Оранжевый для nature
      margin: 0,
      padding: 0,
      transition: 'background-color 0.5s ease'
    }}>
      {currentScreen === 'initial' && (
        <div style={textContainerStyle}>
          <h1 
            style={{...baseTextStyle, color: 'white'}}
            onClick={() => setCurrentScreen('second')}
            onMouseOver={(e) => e.target.style.transform = 'scale(1.1)'}
            onMouseOut={(e) => e.target.style.transform = 'scale(1)'}
          >
            собака
          </h1>
          
          <h1 
            style={{...baseTextStyle, color: 'white'}}
            onClick={() => setCurrentScreen('third')}
            onMouseOver={(e) => e.target.style.transform = 'scale(1.1)'}
            onMouseOut={(e) => e.target.style.transform = 'scale(1)'}
          >
            олень
          </h1>

          {/* Новая кнопка "природа" */}
          <h1 
            style={{...baseTextStyle, color: 'white', fontSize: '48px'}} // Уменьшен размер
            onClick={() => setCurrentScreen('nature')}
            onMouseOver={(e) => e.target.style.transform = 'scale(1.1)'}
            onMouseOut={(e) => e.target.style.transform = 'scale(1)'}
          >
            природа
          </h1>
        </div>
      )}

      {currentScreen === 'second' && (
        <h1 
          style={{...baseTextStyle, color: 'black'}}
          onClick={() => setCurrentScreen('initial')}
        >
          привет
        </h1>
      )}

      {currentScreen === 'third' && (
        <h1 
          style={{...baseTextStyle, color: 'white'}}
          onClick={() => setCurrentScreen('initial')}
        >
          охота
        </h1>
      )}

      {/* Новый экран для "природа" */}
      {currentScreen === 'nature' && (
        <h1 
          style={{...baseTextStyle, color: 'black', fontSize: '72px'}}
          onClick={() => setCurrentScreen('initial')}
        >
          лес
        </h1>
      )}
    </div>
  );
}

export default App;