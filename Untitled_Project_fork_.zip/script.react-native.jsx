import React, { useState } from 'react';

function App() {
  const [currentScreen, setCurrentScreen] = useState('initial');

  // Исправлено: убрано смещение влево для лучшей видимости
  const textContainerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    gap: '30px',
    position: 'relative',
    // left: '-50px'  // Закомментировано для тестирования
  };

  // Общие стили для текста
  const baseTextStyle = {
    color: 'white',
    fontSize: '72px',
    fontWeight: 'bold',
    textShadow: '2px 2px 4px rgba(0, 0, 0, 0.5)',
    cursor: 'pointer',
    transition: 'transform 0.3s ease',
  };

  return (
    <div style={{ 
      width: '100vw', 
      height: '100vh', 
      backgroundColor: currentScreen === 'initial' ? '#1E90FF' : 
                       currentScreen === 'second' ? '#FFD700' : '#000000',
      margin: 0,
      padding: 0,
      transition: 'background-color 0.5s ease'
    }}>
      {currentScreen === 'initial' && (
        <div style={textContainerStyle}>
          {/* Исправлено: теперь переход на 'second' */}
          <h1 
            style={{...baseTextStyle, color: 'white'}}
            onClick={() => setCurrentScreen('second')}
            onMouseOver={(e) => e.target.style.transform = 'scale(1.1)'}
            onMouseOut={(e) => e.target.style.transform = 'scale(1)'}
          >
            собака
          </h1>
          
          <h1 
            style={{...baseTextStyle, color: 'white'}}
            onClick={() => setCurrentScreen('third')}
            onMouseOver={(e) => e.target.style.transform = 'scale(1.1)'}
            onMouseOut={(e) => e.target.style.transform = 'scale(1)'}
          >
            олень
          </h1>
        </div>
      )}

      {currentScreen === 'second' && (
        <h1 
          style={{...baseTextStyle, color: 'black'}}
          onClick={() => setCurrentScreen('initial')}
        >
          привет
        </h1>
      )}

      {currentScreen === 'third' && (
        <h1 
          style={{...baseTextStyle, color: 'white'}}
          onClick={() => setCurrentScreen('initial')}
        >
          охота
        </h1>
      )}
    </div>
  );
}

export default App;